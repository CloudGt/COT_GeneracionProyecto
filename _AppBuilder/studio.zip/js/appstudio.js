﻿(function () {
    //$(document).ready(function () {
    //    if (location.href.match(/\?activationCode=/))
    //        location.replace('https://my.codeontime.com/pages/home?done=');
    //    else {
    //        var productRegistration = $app.data.ProductRegistration;
    //        if (productRegistration) {
    //            var studioPort = productRegistration[0].StudioPort;
    //            if (studioPort )
    //                location.replace('https://my.codeontime.com/pages/home?studio=' + studioPort);
    //        }
    //    }
    //});
})();